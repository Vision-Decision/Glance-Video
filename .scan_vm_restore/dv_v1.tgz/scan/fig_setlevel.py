"""Figure: set-level false alarm and miss vs scan length N (Charades-STA frame pilot).

python scan/fig_setlevel.py outputs/scan/pilot_frames_v1_analysis.json outputs/scan/fig_setlevel
Left: P(alarm | the event never happens) for the naive per-frame rule (p > 0.5, dashed) and the max-statistic
conformal rule (solid); the grey line is alpha. Right: miss rate of the conformal rule at that guaranteed alarm rate.
"""
import json, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = json.load(open(sys.argv[1]))
out = sys.argv[2]
alpha = d["alpha"]
# fixed categorical order (validated default palette, slots 1-4)
SC = [("g_box", "Glance box presence", "#2a78d6"), ("g_yes", "Glance yes/no", "#eb6834"),
      ("base_yes", "Qwen3.5 base P(yes)", "#1baf7a"), ("siglip", "SigLIP2 embedding", "#eda100")]
INK, MUTED, GRID = "#1f1f1e", "#6b6a64", "#e6e5e0"
plt.rcParams.update({"font.size": 9, "axes.edgecolor": MUTED, "axes.labelcolor": INK, "xtick.color": MUTED,
                     "ytick.color": MUTED, "axes.spines.top": False, "axes.spines.right": False})
fig, (a1, a2) = plt.subplots(1, 2, figsize=(8.2, 3.1), constrained_layout=True)
for key, name, c in SC:
    r = d["scorers"][key]["none_of_these"]
    Ns = sorted(int(n) for n, v in r.items() if v["maxstat"]["false_alarm"] is not None)
    fa_n = [r[str(n)]["naive"]["false_alarm"] for n in Ns]
    fa_m = [r[str(n)]["maxstat"]["false_alarm"] for n in Ns]
    miss = [r[str(n)]["maxstat"]["miss"] for n in Ns]
    a1.plot(Ns, fa_n, ls="--", lw=2, color=c, marker="o", ms=4)
    a1.plot(Ns, fa_m, ls="-", lw=2, color=c, marker="o", ms=4, label=name)
    a2.plot(Ns, miss, ls="-", lw=2, color=c, marker="o", ms=4, label=name)
for ax in (a1, a2):
    ax.set_xscale("log", base=2); ax.set_xticks([8, 16, 32, 64, 128]); ax.set_xticklabels(["8", "16", "32", "64", "128"])
    ax.grid(axis="y", color=GRID, lw=0.8); ax.set_xlabel("frames per scan (N)")
a1.axhline(alpha, color=MUTED, lw=1)
a1.text(8.3, alpha + 0.02, f"α = {alpha}", color=MUTED, fontsize=8)
a1.text(20, 0.62, "naive p > 0.5 (dashed)", color=INK, fontsize=8)
a1.text(20, 0.16, "max-statistic conformal (solid)", color=INK, fontsize=8)
a1.set_ylim(0, 0.92); a1.set_ylabel("false alarm on 'never happens'")
a1.set_title("Set-level false alarm", loc="left", color=INK, fontsize=10)
a2.set_ylim(0, 0.7); a2.set_ylabel("miss rate at false alarm ≤ α")
a2.set_title("Cost of the guarantee", loc="left", color=INK, fontsize=10)
a2.legend(frameon=False, fontsize=8, loc="upper left")
fig.savefig(out + ".png", dpi=200); fig.savefig(out + ".pdf")
print("wrote", out + ".png")

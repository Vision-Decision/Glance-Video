"""Shared, model-free workload helpers for the scan benchmarks (importable from the vLLM venv)."""
import json, os
from PIL import Image

from dv.data.dataset import resize_dims


def load_images(prep, root, n, max_vis, frame=False):
    recs = [json.loads(l) for l in open(prep)]
    out = []
    for r in recs:
        p = f"{root}/{r['file']}"
        if not os.path.exists(p):
            continue
        img = Image.open(p).convert("RGB")
        W, H = img.size
        w, h = resize_dims(640, 480, max_vis, 2.0) if frame else resize_dims(W, H, max_vis, 2.0)
        out.append(dict(img=img.resize((w, h), Image.BICUBIC), wh=(W, H), qs=r["questions"]))
        if len(out) >= n:
            break
    return out


QUERIES = ["person standing", "a red car", "the dog on the left", "man in a blue shirt holding a phone", "white plate",
           "the umbrella", "a cat sleeping on the sofa", "bus", "woman with glasses near the window", "green bottle",
           "the clock on the wall", "a child riding a bike", "laptop", "horse", "the tallest giraffe", "pizza slice"]

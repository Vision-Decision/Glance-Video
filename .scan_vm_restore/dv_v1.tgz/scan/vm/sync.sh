#!/usr/bin/env bash
# Push code (dv/, speed/, scan/, small preps) + HF token to /content/dv on a pooled VM.   scan/vm/sync.sh SESSION
set -euo pipefail
S=${1:?session}
cd "$(dirname "$0")/../.."
export COPYFILE_DISABLE=1
TMP=$(mktemp -d)
tar czf "$TMP/c.tgz" --exclude=__pycache__ dv speed scan video/vdm/gv train.py eval.py configs \
  data/prep/eval_refcoco_val.jsonl data/prep/eval_grefcoco_val.jsonl ${SYNC_EXTRA:-}
cp ~/.cache/huggingface/token "$TMP/hf_token"
timeout 300 colab-pool upload "$S" "$TMP/hf_token" /content/hf_token >/dev/null
timeout 600 colab-pool upload "$S" "$TMP/c.tgz" /content/c.tgz >/dev/null
bash scan/vm/sh.sh "$S" 'mkdir -p /content/dv /root/.cache/huggingface && cp /content/hf_token /root/.cache/huggingface/token && tar xzf /content/c.tgz -C /content/dv && ls /content/dv' 200
rm -rf "$TMP"

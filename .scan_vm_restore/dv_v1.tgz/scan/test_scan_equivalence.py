"""Exactness of the scan engine: one query over N images in one forward == each image run alone.

Checks (tiny random Qwen3.5 config, fp32, CPU by default; --real uses the real weights + a checkpoint on GPU, bf16):
  cached   ScanEngine.encode (chunked, banks of different prefix lengths concatenated) + query()  vs  run_model_v1
           on each (image, question) alone (dv.model reference path)
  fresh    ScanEngine.fresh (all N images + blocks in one call)                                  vs  same reference
  hf       (causal mask only) the plain HF forward over [prefix + block] with the box head applied to its hidden
           states                                                                                  vs  cached
  isolate  changing image k changes only answer k
  repeat   querying the same bank twice gives identical answers (the cached state is not mutated)
  qfirst   query-first prefix: fresh() == each image alone with the same prefix

python -m scan.test_scan_equivalence [--real --ckpt PATH] [--n 6]
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import numpy as np
import torch
from PIL import Image
from transformers import AutoConfig, AutoProcessor, AutoModelForImageTextToText

from dv.config import Config
from dv.data.mixed import ChatTok, collate_mixed
from dv.model.backbone import SharedPrefixLM
from dv.model.build import V1Heads
from dv.model.v1forward import run_model_v1
import speed.engine as SE
from scan.engine import ScanEngine, make_item, make_clip_item

ap = argparse.ArgumentParser()
ap.add_argument("--model_id", default="Qwen/Qwen3.5-4B")
ap.add_argument("--real", action="store_true")
ap.add_argument("--ckpt", default="")
ap.add_argument("--n", type=int, default=6)
ap.add_argument("--mask", default="both", choices=["both", "causal", "block_bidir"])
a = ap.parse_args()
torch.manual_seed(0)
dev = "cuda" if (a.real and torch.cuda.is_available()) else "cpu"
proc = AutoProcessor.from_pretrained(a.model_id)

if a.real:
    from dv.model.build import build, load_ckpt
    sd = torch.load(a.ckpt, map_location="cpu", weights_only=False)
    cfg0 = Config().update({k: v for k, v in sd["cfg"].items() if k in Config.__dataclass_fields__})
    net0, heads, _ = build(cfg0, dev)
    load_ckpt(a.ckpt, net0, heads)
    hf = net0.hf
else:
    c = AutoConfig.from_pretrained(a.model_id)
    t = c.text_config
    t.hidden_size, t.intermediate_size, t.num_hidden_layers = 128, 256, 8
    t.layer_types = t.layer_types[:8]
    t.num_attention_heads, t.num_key_value_heads, t.head_dim = 4, 2, 32
    t.linear_num_key_heads, t.linear_num_value_heads, t.linear_key_head_dim, t.linear_value_head_dim = 2, 4, 16, 16
    v = c.vision_config
    v.depth, v.hidden_size, v.intermediate_size, v.num_heads, v.out_hidden_size = 1, 64, 128, 2, 128
    hf = AutoModelForImageTextToText.from_config(c, dtype=torch.float32).to(dev)
    SE.USE_TAPS = False          # torch.compile'd conv taps are a GPU fast path; CPU uses F.conv1d (reference op)
hf.eval()

rng = np.random.RandomState(0)
sizes = [(320, 240), (200, 300), (256, 256), (320, 240), (160, 480), (288, 224), (224, 224), (192, 320)][: a.n]
images = [Image.fromarray((rng.rand(H, W, 3) * 255).astype("uint8")) for W, H in sizes]
QS = [dict(type="box", text="the red car on the left"),
      dict(type="noul", instr="Is there a person falling down in the image?"),
      dict(type="choice", instr="What is shown?", options=["a car", "a dog", "nothing"])]

errs, ok = {}, True


def rel(x, y):
    x, y = x.float(), y.float()
    fin = torch.isfinite(y)
    return ((x - y).abs()[fin].max() / y.abs()[fin].max().clamp(min=1e-6)).item() if fin.any() else 0.0


def reference(net, heads, tok, images, q, query_first=None, clip_kw=None):
    """run_model_v1 on each (image or clip, question) alone (clips: HF video features, native video prefix)."""
    rows = []
    for im in images:
        it = make_clip_item(tok, proc, im, [q], query_first=query_first, **clip_kw) if clip_kw else \
            make_item(tok, proc, im, [q], query_first)
        b = collate_mixed([it], tok); b.pop("meta", None)
        b = {k: (v.to(dev) if torch.is_tensor(v) else v) for k, v in b.items()}
        with torch.no_grad():
            r = run_model_v1(net, heads, b, train=False)
        if q["type"] == "box":
            rows.append(dict(presence_logit=r["box"]["presence_logit"].float().cpu(), box_pred=r["box"]["box_pred"].float().cpu(),
                             iou_logit=r["box"]["iou_logit"].float().cpu()))
        else:
            rows.append(dict(typed_logits=r["typed_logits"].float().cpu()))
    return {k: torch.cat([r[k] for r in rows]) for k in rows[0]}


def compare(tag, out, ref):
    global ok
    e = max(rel(out[k][:, :ref[k].shape[1]] if out[k].dim() > 1 else out[k], ref[k]) for k in ref)
    errs[tag] = e
    tol = 2e-2 if a.real else 1e-4
    ok &= e < tol


masks = ["causal", "block_bidir"] if a.mask == "both" else [a.mask]
for mode in masks:
    cfg = Config().update(dict(task="v1", attn_mask=mode, max_vis_tokens=64 if not a.real else 640, grad_ckpt=False))
    net = SharedPrefixLM(hf, cfg).eval()
    tok = ChatTok(proc, cfg)
    if not a.real:
        heads = V1Heads(net.hidden, cfg, hf.get_output_embeddings().weight, tok.label_token_groups()).to(dev).eval()
        for p in heads.parameters():          # non-trivial typed residual (zero-init in training)
            if p.dim() == 2 and p.shape[0] < 40:
                torch.nn.init.normal_(p, std=0.02)
    eng = ScanEngine(net, heads, tok, proc, graphs=False, fast_ops=False)
    # resize like the real pipeline (multiples of 32 px)
    from dv.data.dataset import resize_dims
    ims = [im.resize(resize_dims(*im.size, cfg.max_vis_tokens, 2.0), Image.BICUBIC) for im in images]
    bank = eng.encode(ims, chunk=2)                        # several banks, different prefix lengths -> concat
    for q in QS:
        ref = reference(net, heads, tok, ims, q)
        compare(f"{mode}/{q['type']}/cached_vs_alone", eng.query(bank, q), ref)
        compare(f"{mode}/{q['type']}/fresh_vs_alone", eng.fresh(ims, q), ref)
        o1, o2 = eng.query(bank, q), eng.query(bank, q)
        errs[f"{mode}/{q['type']}/repeat"] = max((o1[k] - o2[k]).abs().max().item() for k in ("presence_logit", "box_pred"))
        ok &= errs[f"{mode}/{q['type']}/repeat"] == 0
    # isolation: perturb image 1, re-encode; only answer 1 may change
    q = QS[0]
    ims2 = list(ims)
    ims2[1] = Image.fromarray(255 - np.asarray(ims[1]))
    o_a, o_b = eng.query(bank, q), eng.query(eng.encode(ims2, chunk=2), q)
    d = (o_a["presence_logit"] - o_b["presence_logit"]).abs()
    errs[f"{mode}/isolate_others_maxdiff"] = float(torch.cat([d[:1], d[2:]]).max())
    errs[f"{mode}/isolate_changed"] = float(d[1])
    ok &= errs[f"{mode}/isolate_others_maxdiff"] < (1e-5 if not a.real else 1e-2) and errs[f"{mode}/isolate_changed"] > 0
    # query-first prefix (mode C)
    qf = "the red car on the left"
    compare(f"{mode}/qfirst_fresh_vs_alone", eng.fresh(ims, q, query_first=True), reference(net, heads, tok, ims, q, query_first=qf))
    # plain HF forward (only the causal block mask is an ordinary causal LM)
    if mode == "causal":
        out = eng.query(bank, q)
        diffs = []
        for i, im in enumerate(ims):
            it = make_item(tok, proc, im, [q])
            b = collate_mixed([it], tok)
            pv = b["p_valid"][0]
            ids = torch.cat([b["p_ids"][0][pv], b["q_ids"][0][b["q_valid"][0]]])[None].to(dev)
            mm = (ids == hf.config.image_token_id).int()
            with torch.no_grad():
                h = hf.model(input_ids=ids, pixel_values=b["pixel_values"].to(dev), image_grid_thw=b["grid_thw"].to(dev),
                             mm_token_type_ids=mm).last_hidden_state[0]
                vis = h[(ids[0] == hf.config.image_token_id)][None]
                n = vis.shape[1]
                r = heads.box(h[-1:], vis, torch.ones(1, n, dtype=torch.bool, device=dev),
                              b["centers"][:, :n].to(dev), torch.zeros(1, dtype=torch.long, device=dev))
            diffs.append(rel(out["presence_logit"][i:i + 1], r["presence_logit"].float().cpu()))
            diffs.append(rel(out["box_pred"][i:i + 1], r["box_pred"].float().cpu()))
        errs["causal/box/cached_vs_hf_plain_forward"] = max(diffs)
        ok &= max(diffs) < (1e-4 if not a.real else 3e-2)

# clip units (Glance-Video native video prefix): 5 clips of 4 frames (2 temporal groups), one clip of 6 frames
    clips = [[Image.fromarray((rng.rand(96, 128, 3) * 255).astype("uint8")) for _ in range(4)] for _ in range(5)]
    clips.append([Image.fromarray((rng.rand(96, 128, 3) * 255).astype("uint8")) for _ in range(6)])
    eng.dt, eng.clip_max_vis = 0.5, 16
    ckw = dict(dt=0.5, max_vis=16)
    cbank = eng.encode(clips, chunk=2)
    for q in QS[1:]:
        ref = reference(net, heads, tok, clips, q, clip_kw=ckw)
        compare(f"{mode}/clip/{q['type']}/cached_vs_alone", eng.query(cbank, q), ref)
        compare(f"{mode}/clip/{q['type']}/fresh_vs_alone", eng.fresh(clips, q), ref)
    qf = "a person falling"
    compare(f"{mode}/clip/qfirst_fresh_vs_alone", eng.fresh(clips, QS[1], query_first=True),
            reference(net, heads, tok, clips, QS[1], query_first=QS[1]["instr"], clip_kw=ckw))

# demo API smoke test (last engine): per-image answers + calibrated set answer
from scan.api import Scanner
sc = Scanner(eng, max_vis=64)
r1 = sc.scan("a red car", images, mode="cached")
r2 = sc.scan("a dog", images, mode="cached")                    # bank reused
r3 = sc.scan("a dog", images, mode="fresh")
negs = [np.random.RandomState(i).normal(-2, 1, len(images)) for i in range(50)]
sc.calibrate(negs)
r4 = sc.scan("a dog", images, mode="cached")
errs["api/cached_vs_fresh_p"] = max(abs(a["p_present"] - b["p_present"]) for a, b in zip(r2["images"], r3["images"]))
ok &= errs["api/cached_vs_fresh_p"] < 1e-4 and "encode" not in r2["latency_ms"] and "none_conformal" in r4["set"]
rc = sc.scan("a person falling", clips, mode="cached", readout="short")
rf = sc.scan("a person falling", clips, mode="fresh", readout="short")
errs["api/clips_short_cached_vs_fresh"] = max(abs(x["p_yes"] - y["p_yes"]) for x, y in zip(rc["images"], rf["images"]))
ok &= errs["api/clips_short_cached_vs_fresh"] < 1e-4 and len(rc["images"]) == len(clips)
print("api example:", {k: v for k, v in r4["set"].items() if k != "curve"}, r4["latency_ms"])
# vdm scan server end to end (HTTP, tiny model): /encode, /scan (curve/ever/when/count), /score_clips (vdm1 API)
if not a.real:
    import base64, io, json, threading, urllib.request, urllib.error
    from http.server import ThreadingHTTPServer
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "video", "vdm", "gv"))
    import scan_server as SS
    from scan import video_ops as VO
    SS.ENG = eng
    eng.dt, eng.clip_max_vis = 0.5, 16

    def b64(im):
        b = io.BytesIO(); im.save(b, "JPEG", quality=90); return base64.b64encode(b.getvalue()).decode()
    cl_b64 = [[b64(f) for f in c[:4]] for c in clips]
    srv = ThreadingHTTPServer(("127.0.0.1", 0), SS.H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    url = f"http://127.0.0.1:{srv.server_address[1]}"
    def post(p, body):
        try:
            return json.load(urllib.request.urlopen(urllib.request.Request(url + p, json.dumps(body).encode(),
                                                                           {"content-type": "application/json"})))
        except urllib.error.HTTPError as e:
            return json.load(e)
    r0 = post("/scan", dict(video="v1", query="a person falling"))
    times = [[i * 1.0, i * 1.0 + 1.5] for i in range(len(clips))]
    r1 = post("/encode", dict(video="v1", clips=cl_b64, times=times, dt=0.5))
    r2 = post("/scan", dict(video="v1", query="a person falling", ops=["curve", "ever", "when", "count"]))
    rng2 = np.random.RandomState(1)
    SS.CAL = VO.Calib(rng2.normal(-2, 1, 2000), [rng2.normal(-2, 1, len(clips)) for _ in range(60)])
    r3 = post("/scan", dict(video="v1", query="a person falling", ops=["curve", "ever", "when", "count"], alpha=0.1))
    r4 = post("/score_clips", dict(question="Is a person falling?", kind="yesno", dt=0.5, clips=cl_b64))
    r5 = post("/score_clips", dict(question="Is a person falling?", kind="yesno", dt=0.5, clips=cl_b64))
    # the server's clips are re-decoded JPEGs, so compare the server against itself + the direct engine on the same JPEGs
    dec = [[Image.open(io.BytesIO(base64.b64decode(f))).convert("RGB") for f in c] for c in cl_b64]
    direct = eng.fresh(dec, dict(type="noul", instr="Is a person falling?"))["typed_logits"]
    p_direct = torch.softmax(direct[:, :2], -1)[:, 1]
    errs["server/score_clips_vs_direct"] = float(max(abs(x - float(y)) for x, y in zip(r4["results"], p_direct)))
    ok &= ("error" in r0 and "unknown video" in r0["error"]) and r1["n"] == len(clips) and len(r2["curve"]) == len(clips)
    ok &= r2["ever"]["guarantee"] is None and "guarantee" in r3["ever"] and "intervals" in r3["when"] and "count" in r3["count"]
    ok &= (not r4["cached"]) and r5["cached"] and errs["server/score_clips_vs_direct"] < 1e-4
    print("server:", {k: r3[k] for k in ("ever", "count")}, "cached second call:", r5["cached"])
    srv.shutdown()

for k, v in errs.items():
    print(f"{k:45s} {v:.3e}")
print(f"N={len(images)} images, bank Lp ok")
print("SCAN_EQUIVALENCE_OK" if ok else "SCAN_EQUIVALENCE_FAIL")

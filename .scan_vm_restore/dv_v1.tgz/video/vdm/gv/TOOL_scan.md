Extra tool `vdmscan` (on PATH): a fast clip-level event scanner (Glance-Video, a 4B video decision model on a GPU server)
for video.mp4. It cuts the video into 2-second clips (4 frames, a new clip every second; long videos use proportionally
longer clips, at most 600) and encodes them ONCE: the first call on a video/range takes ~0.5-3 min, every later question
on the same video/range returns in about a second. It answers one short visual event phrase per clip (no audio, no
speech, nothing that needs more than a few seconds of context). Output: a '# ...' summary line (add --json for details).
- `vdmscan when video.mp4 "a hand pulls a wipe out of a box" [--in t0-t1]` -> time intervals where the event is seen, with probabilities.
- `vdmscan count video.mp4 "the person dips a brush into the paint" [--in t0-t1]` -> number of separate occurrences and their
  times (occurrences closer than ~2 s merge; for fast repetitions in a short span use `reps`).
- `vdmscan ever video.mp4 "a dog runs across the street" [--in t0-t1]` -> YES/NO. YES is calibrated: if the event never
  happens, a false YES comes out at most ~10% of the time (`--alpha`). NO can still miss brief or small events, so treat
  NO as evidence, not proof.
- `vdmscan reps video.mp4 "squats" --in t0-t1` (span <= 180 s) -> repetition count of a periodic action, per 4-s window.
- `vdmscan curve video.mp4 "..."` -> probability peaks and a coarse P(t) profile.
How to use it: break the question into concrete visual sub-questions ("when does X happen", "how many times does Y occur",
"does Z ever appear") and scan those; then open frames at the returned times to confirm before answering. Phrase queries
as a short event or object you could see in a 2-s clip ("the person closes the drawer"), not as the multiple-choice question.
Do NOT scan the answer options themselves to pick one: on this benchmark the option texts are written so that visual
similarity points to distractors; the tool's job is to find and count events, and your job is to reason from them.

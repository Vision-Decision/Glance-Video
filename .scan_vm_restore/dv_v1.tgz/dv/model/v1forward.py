"""v1 forward over a mixed batch (image and/or text prefixes; box + typed questions). Shared by train / eval / inference."""
import torch

from .heads import center_target_box, center_target_points
from .typed import typed_logits


def run_model_v1(net, heads, batch, train=True):
    """Mixed batch: image and/or text prefixes; box + typed questions. Returns dict of head outputs."""
    feats = net.image_features(batch["pixel_values"], batch["grid_thw"]) if batch["pixel_values"] is not None else []
    if batch.get("pixel_values_videos") is not None:  # Glance-Video: batches are homogeneous (sampler groups by kind)
        assert not feats, "mixed image+video micro-batch"
        feats = net.video_features(batch["pixel_values_videos"], batch["video_grid_thw"])
    with torch.autocast("cuda", dtype=torch.bfloat16):
        hp, hq = net(batch, feats)
    M = hq.shape[0]
    hq_last = hq[torch.arange(M, device=hq.device), batch["q_last"]]
    res = dict(qtype=batch["qtype"])
    is_box = batch["qtype"] == 0
    typed = ~is_box
    if typed.any():
        lab = heads.typed(hq_last[typed])
        res["typed_logits"] = typed_logits(lab, batch["lab_idx"][typed])
        res["typed_mask"] = typed
    if is_box.any():
        bi = is_box.nonzero()[:, 0]
        B, N = batch["vis_valid"].shape
        vis = hp.new_zeros(B, N, hp.shape[-1])
        vis[batch["vis_valid"]] = hp[batch["p_img_mask"]]
        q_img = batch["q_img"][bi]
        valid = batch["vis_valid"][q_img]
        cen = batch["centers"][q_img]
        ghw = batch["grid_hw"][bi]
        ct = sel = None
        if train:
            ct = center_target_box(batch["box"][bi], cen, valid, ghw) * batch["has_box"][bi, None]
            if len(batch["pt_m"]):
                remap = torch.full((M,), -1, dtype=torch.long, device=bi.device)
                remap[bi] = torch.arange(len(bi), device=bi.device)
                pm = remap[batch["pt_m"]]
                keep = pm >= 0
                ct = ct + center_target_points(pm[keep], batch["pt_xy"][keep], len(bi), cen, valid, ghw)
            noct = ct.sum(-1) <= 0
            sel = torch.multinomial(ct + noct[:, None] * valid.float() + 1e-12, 1)[:, 0]
        out = heads.box(hq_last[bi], vis, batch["vis_valid"], batch["centers"], q_img, sel_idx=sel)
        res.update(box=out, box_idx=bi, center_t=ct)
    return res
